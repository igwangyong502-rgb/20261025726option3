#!/usr/bin/env python3
"""Top-level Commit precheck orchestrator. Read-only."""

import argparse, hashlib, json, subprocess, sys, tempfile, zipfile
from pathlib import Path

BL = "02_engine/volatility_model/bl_density.py"
BL_SHA = "ce4e5180cf37114d05459ebc1b8accc1dd00a4e8ca5adf4bb57eeabc53c49b3f"
APPROVED = {
    "02_engine/volatility_model/quality.py",
    "02_engine/volatility_model/tests/test_quality.py",
    "02_engine/volatility_model/tests/bl_synthetic_validation_v1.py",
}
HELD_PREFIX = "02_engine/universal_quant_engine/"

def h(data):
    return hashlib.sha256(data).hexdigest()

def zip_hash(z, name):
    with zipfile.ZipFile(z) as f:
        return h(f.read(name)) if name in f.namelist() else None

def tree(root):
    return {str(p.relative_to(root)).replace("\\","/") for p in root.rglob("*") if p.is_file()}

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--workspace", required=True)
    p.add_argument("--baseline", required=True)
    p.add_argument("--current-zip")
    p.add_argument("--output", default="commit_precheck_report.json")
    a = p.parse_args()

    ws = Path(a.workspace)
    report = {"stage": "COMMIT_PRECHECK", "checks": {}}

    current = tree(ws)
    report["checks"]["approved_scope_present"] = sorted(APPROVED & current)
    report["checks"]["approved_scope_ok"] = (APPROVED <= current)

    bl_path = ws / BL
    actual_bl = h(bl_path.read_bytes()) if bl_path.is_file() else None
    report["checks"]["bl_density_sha256"] = {
        "expected": BL_SHA, "actual": actual_bl,
        "status": "PASS" if actual_bl == BL_SHA else "FAIL"
    }

    baseline = Path(a.baseline)
    if baseline.is_file():
        with zipfile.ZipFile(baseline) as z:
            base_names = {n.replace("\\","/").lstrip("./") for n in z.namelist() if not n.endswith("/")}
        report["checks"]["baseline_zip"] = {
            "status": "PASS",
            "file_count": len(base_names),
            "bl_density_sha256": zip_hash(baseline, BL),
        }
    else:
        report["checks"]["baseline_zip"] = {"status": "BLOCKED", "reason": "baseline ZIP missing"}

    held = sorted(
        x for x in current
        if x == BL or x.startswith(HELD_PREFIX) or x.endswith("dashboard_ab.py")
    )
    report["checks"]["held_scope_present"] = held
    report["checks"]["held_scope_ok"] = not held

    report["overall_status"] = (
        "PASS"
        if report["checks"]["approved_scope_ok"]
        and report["checks"]["bl_density_sha256"]["status"] == "PASS"
        and report["checks"]["baseline_zip"]["status"] == "PASS"
        and report["checks"]["held_scope_ok"]
        else "HOLD"
    )

    Path(a.output).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(0 if report["overall_status"] == "PASS" else 1)

if __name__ == "__main__":
    main()
