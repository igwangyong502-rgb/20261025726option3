#!/usr/bin/env python3
"""Verify approved/forbidden file scope. Read-only."""

import argparse, json, zipfile
from pathlib import Path

APPROVED = {
    "02_engine/volatility_model/quality.py",
    "02_engine/volatility_model/tests/test_quality.py",
    "02_engine/volatility_model/tests/bl_synthetic_validation_v1.py",
}
FORBIDDEN_PREFIXES = (
    "02_engine/universal_quant_engine/",
)
FORBIDDEN_EXACT = {
    "02_engine/volatility_model/bl_density.py",
    "dashboard_ab.py",
}

def norm(s):
    return s.replace("\\", "/").lstrip("./")

def files_from_dir(root):
    return {norm(str(p.relative_to(root))) for p in root.rglob("*") if p.is_file()}

def files_from_zip(path):
    with zipfile.ZipFile(path) as z:
        return {norm(n) for n in z.namelist() if not n.endswith("/")}

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--workspace")
    p.add_argument("--zip")
    p.add_argument("--baseline")
    a = p.parse_args()

    if not a.workspace and not a.zip:
        p.error("use --workspace or --zip")

    actual = files_from_dir(Path(a.workspace)) if a.workspace else files_from_zip(Path(a.zip))
    approved_present = sorted(x for x in actual if x in APPROVED)
    forbidden_present = sorted(
        x for x in actual
        if x in FORBIDDEN_EXACT or any(x.startswith(prefix) for prefix in FORBIDDEN_PREFIXES)
    )

    print("APPROVED PRESENT:")
    for x in approved_present:
        print("  +", x)
    print("FORBIDDEN/HELD PRESENT:")
    for x in forbidden_present:
        print("  !", x)

    missing = sorted(APPROVED - set(approved_present))
    print("MISSING APPROVED:")
    for x in missing:
        print("  -", x)

    ok = len(approved_present) == 3 and not forbidden_present
    print("PASS" if ok else "FAIL")
    raise SystemExit(0 if ok else 1)

if __name__ == "__main__":
    main()
