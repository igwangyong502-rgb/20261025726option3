#!/usr/bin/env python3
"""Compare two ZIP trees without extracting or modifying either archive."""

import argparse, hashlib, json, zipfile
from pathlib import PurePosixPath

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read_zip(path):
    out = {}
    with zipfile.ZipFile(path) as z:
        for n in z.namelist():
            n = n.replace("\\", "/").lstrip("./")
            if n.endswith("/"):
                continue
            out[n] = sha(z.read(n))
    return out

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--baseline", required=True)
    p.add_argument("--current", required=True)
    p.add_argument("--output", default="zip_manifest_diff.json")
    a = p.parse_args()

    base = read_zip(a.baseline)
    cur = read_zip(a.current)

    added = sorted(set(cur) - set(base))
    removed = sorted(set(base) - set(cur))
    modified = sorted(k for k in set(base) & set(cur) if base[k] != cur[k])
    unchanged = sorted(k for k in set(base) & set(cur) if base[k] == cur[k])

    result = {
        "added": added,
        "removed": removed,
        "modified": modified,
        "unchanged_count": len(unchanged),
        "approved_added": [
            x for x in added if x in {
                "02_engine/volatility_model/quality.py",
                "02_engine/volatility_model/tests/test_quality.py",
                "02_engine/volatility_model/tests/bl_synthetic_validation_v1.py",
            }
        ],
        "forbidden_changes": [
            x for x in modified
            if x == "02_engine/volatility_model/bl_density.py"
            or x.startswith("02_engine/universal_quant_engine/")
            or x.endswith("dashboard_ab.py")
        ],
    }

    Path = __import__("pathlib").Path
    Path(a.output).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    ok = (
        not result["removed"]
        and set(result["added"]) == {
            "02_engine/volatility_model/quality.py",
            "02_engine/volatility_model/tests/test_quality.py",
            "02_engine/volatility_model/tests/bl_synthetic_validation_v1.py",
        }
        and not result["forbidden_changes"]
    )
    print("PASS" if ok else "FAIL")
    raise SystemExit(0 if ok else 1)

if __name__ == "__main__":
    main()
