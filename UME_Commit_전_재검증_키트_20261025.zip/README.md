# UME Commit 전 재검증 Kit

목적: 승인 ① 구현본을 Commit 전에 독립적으로 재검증한다.

원칙:
- 대상 작업본은 읽기 전용으로 취급한다.
- 이 Kit 자체가 UME 소스 파일을 수정하지 않는다.
- Approval A 기준선과 현재 구현본을 비교한다.
- `bl_density.py` SHA-256 보존 여부를 확인한다.
- 승인 ① 변경 파일이 정확히 3개인지 확인한다.
- 승인 ②/③ 파일이 섞이지 않았는지 확인한다.
- 테스트는 실제 대상 작업환경에서 별도로 실행하고 로그를 보존한다.
- 37/37은 실제 재실행 전까지 확정하지 않는다.

권장 실행:
1. `python run_precheck.py --workspace <현재_작업본> --baseline <ApprovalA_압축파일>`
2. 필요하면 `python verify_sha.py ...`
3. `python verify_scope.py ...`
4. `python verify_tests.py --workspace ...`
5. 결과 `commit_precheck_report.json` 확인

주의:
- baseline ZIP이 없으면 baseline 비교는 FAIL이 아니라 `BLOCKED`로 기록한다.
- 테스트 실행 실패와 테스트 미실행을 구분한다.
- 네트워크가 필요한 K1~K7은 이 Kit의 Commit 전 회귀검증과 별개다.
