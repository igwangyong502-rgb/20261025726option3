#!/usr/bin/env python3
"""Run separately defined test groups and preserve a machine-readable report.

This script does not alter source files. It only executes commands supplied
by the caller. Missing commands are recorded as NOT_CONFIGURED.
"""

import argparse, json, subprocess, sys
from pathlib import Path

GROUPS = [
    ("approval_c_quality", "02_engine/volatility_model/tests/test_quality.py"),
    ("m1", "02_engine/volatility_model/tests/test_m1.py"),
    ("vol_bridge", "02_engine/volatility_model/tests/test_bridge.py"),
    ("approval_a_reliability", "02_engine/universal_quant_engine/tests/test_reliability_v1.py"),
    ("collectors", "02_engine/universal_quant_engine/collectors/test_collectors_v1.py"),
]

def run(cmd, cwd):
    r = subprocess.run(cmd, cwd=cwd, shell=True, text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    return {"returncode": r.returncode, "output": r.stdout[-20000:]}

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--workspace", required=True)
    p.add_argument("--commands-json", help="JSON mapping group -> shell command")
    p.add_argument("--output", default="test_reverification_report.json")
    a = p.parse_args()

    commands = json.loads(Path(a.commands_json).read_text(encoding="utf-8")) if a.commands_json else {}
    result = {}
    for group, expected_path in GROUPS:
        cmd = commands.get(group)
        if not cmd:
            result[group] = {"status": "NOT_CONFIGURED", "expected_path": expected_path}
            continue
        result[group] = {"status": "RUNNING", "command": cmd, "expected_path": expected_path}
        r = run(cmd, Path(a.workspace))
        result[group].update(r)
        result[group]["status"] = "PASS" if r["returncode"] == 0 else "FAIL"

    Path(a.output).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
