#!/usr/bin/env python3
"""Read-only SHA-256 verification."""

import argparse, hashlib
from pathlib import Path

EXPECTED = "ce4e5180cf37114d05459ebc1b8accc1dd00a4e8ca5adf4bb57eeabc53c49b3f"

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--workspace", required=True)
    p.add_argument("--relative", default="02_engine/volatility_model/bl_density.py")
    p.add_argument("--expected", default=EXPECTED)
    a = p.parse_args()
    path = Path(a.workspace) / a.relative
    if not path.is_file():
        print(f"BLOCKED: missing {path}")
        raise SystemExit(2)
    actual = sha256(path)
    print(f"path={path}")
    print(f"expected={a.expected}")
    print(f"actual={actual}")
    print("PASS" if actual == a.expected else "FAIL")
    raise SystemExit(0 if actual == a.expected else 1)

if __name__ == "__main__":
    main()
