# Commit 전 재검증 체크리스트

## A. 기준선
- [ ] `ume_vol_a_full_261006.zip` 실제 파일 확보
- [ ] Approval A lineage 확인
- [ ] baseline ZIP SHA 기록

## B. 승인 ① 변경 범위
- [ ] `quality.py` 존재
- [ ] `test_quality.py` 존재
- [ ] `bl_synthetic_validation_v1.py` 존재
- [ ] 위 3개 외 신규/수정 파일 없음

## C. 보호 대상
- [ ] `bl_density.py` SHA-256 = `ce4e5180cf37114d05459ebc1b8accc1dd00a4e8ca5adf4bb57eeabc53c49b3f`
- [ ] Approval A `universal_quant_engine/` 무변경
- [ ] `dashboard_ab.py` 미포함
- [ ] DATA-001/FIN-001 구현물 미포함
- [ ] v3 분리 구현물 미포함

## D. 테스트
- [ ] Approval C quality 재실행
- [ ] M1 재실행
- [ ] vol_bridge 재실행
- [ ] Approval A reliability 재실행
- [ ] collectors 재실행
- [ ] UME/credentials 테스트는 실제 경로가 존재할 경우 별도 실행
- [ ] 37/37은 실제 재현될 때만 PASS로 확정

## E. 최종 산출물
- [ ] ZIP 내부 파일 목록 확정
- [ ] ZIP SHA-256 기록
- [ ] `commit_precheck_report.json` PASS
- [ ] 테스트 로그 보존
- [ ] Commit 직전 마지막 변경 없음 확인

## 판정
PASS → Commit 관문 진입 가능
HOLD → 누락/미검증 항목 보완 후 재검증
FAIL → 변경 범위 또는 보호 대상 침범 원인 분석 후 승인 재검토
